create function login(par_username text, par_password text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_usr text;
    loc_pwd text;
    loc_res text;
  begin
     select into loc_usr account.username from account
       where account.username = par_username and account.password = par_password;

     if loc_usr isnull then
       loc_res = 'Error';
     else
       loc_res = 'ok';
     end if;
     return loc_res;
  end;
$$;
