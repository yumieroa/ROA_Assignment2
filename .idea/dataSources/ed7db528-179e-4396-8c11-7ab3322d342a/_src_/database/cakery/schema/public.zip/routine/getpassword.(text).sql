create function getpassword(par_username text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_password text;
  begin
     select into loc_password password from account where username = par_username;
     if loc_password isnull then
       loc_password = 'null';
     end if;
     return loc_password;
 end;
$$;
