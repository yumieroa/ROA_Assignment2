create function confirmed(con boolean) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

  loc_con BOOLEAN;
  
  begin
    select into loc_con confirmed from orderslip;
     if con NOTNULL then

       update orderslip set confirmed =  'True';
       loc_res = 'ok';
  else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
