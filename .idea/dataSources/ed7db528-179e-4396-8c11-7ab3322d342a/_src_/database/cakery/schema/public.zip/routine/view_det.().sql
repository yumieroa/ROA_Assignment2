create function view_det(OUT character varying, OUT character varying, OUT character varying, OUT character varying, OUT character varying, OUT character varying, OUT character varying) returns SETOF record
LANGUAGE SQL
AS $$
select order_quantity, prod_name, order_total, cust_name, email, contact, address from orderslip where confirmed = 'True';
$$;
