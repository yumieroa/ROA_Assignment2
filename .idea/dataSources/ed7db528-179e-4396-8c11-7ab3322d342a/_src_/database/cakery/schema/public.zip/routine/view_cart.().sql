create function view_cart(OUT character varying, OUT character varying, OUT character varying) returns SETOF record
LANGUAGE SQL
AS $$
select prod_name, order_quantity, order_total from orderslip;
$$;
