create function delete_order(par_del text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

  begin
     if par_del NOTNULL then
        UPDATE orderslip SET order_quantity = 0, order_total = 0, cust_name = 0, email = 0, contact = 0, address = 0, prod_name = 0;
         loc_res = 'ok';
      else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
